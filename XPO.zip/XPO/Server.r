# Server.R

TotalCostUSDModel <- function() {
  read.csv('XPO.csv')
  model <- lm(TotalCostUSD ~ Tier + BuyNonDAT + BuyRateNonDAT + Distance + FreightCharge + FreightPay  + SellNonDAT + FuelCharge + Type, xpo)
  
}

TotalRevenueUSDModel <- function() {
  read.csv('XPO.csv')
  model <- lm(TotalRevenueUSD ~ Tier + BuyNonDAT + BuyRateNonDAT + Distance + FreightCharge + FreightPay + SellNonDAT + FuelCharge + Type, xpo)
  
}


#* @post /TotalCostUSD
TotalCostUSD <- function(inTier,inBuyNonDAT,inBuyRateNonDAT,inDistance,inFreightCharge,inFreightPay,inSellNonDAT,inFuelCharge,inType){
  p_value <- predict(TotalCostUSDModel(), data.frame(Tier=as.numeric(inTier),BuyNonDAT=as.numeric(inBuyNonDAT),BuyRateNonDAT=as.numeric(inBuyRateNonDAT),Distance=as.numeric(inDistance),FreightCharge=as.numeric(inFreightCharge),FreightPay=as.numeric(inFreightPay),SellNonDAT=as.numeric(inSellNonDAT),FuelCharge=as.numeric(inFuelCharge),Type=inType))  
}

#* @post /TotalRevenueUSD
TotalRevenueUSD <- function(inTier,inBuyNonDAT,inBuyRateNonDAT,inDistance,inFreightCharge,inFreightPay,inSellNonDAT,inFuelCharge,inType){
  p_value <- predict(TotalRevenueUSDModel(), data.frame(Tier=as.numeric(inTier),BuyNonDAT=as.numeric(inBuyNonDAT),BuyRateNonDAT=as.numeric(inBuyRateNonDAT),Distance=as.numeric(inDistance),FreightCharge=as.numeric(inFreightCharge),FreightPay=as.numeric(inFreightPay),SellNonDAT=as.numeric(inSellNonDAT),FuelCharge=as.numeric(inFuelCharge),Type=inType))  
}