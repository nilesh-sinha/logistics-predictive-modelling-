import { Component, OnInit, DoCheck } from '@angular/core';
import {FormsModule} from '@angular/forms';
import {ApiCallService} from '../api-call.service';
import { ViewChild } from '@angular/core';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {
  // tslint:disable-next-line:no-trailing-whitespace
@ViewChild('baseChart') baseChart;
  showChart=true;
  public lineChartData:Array<any>;
  public lineChartLabels:Array<any> = ['January', 'February', 'March', 'April', 'May', 'June', 'July'];
  public lineChartOptions:any = {
    responsive: true
  };
  public lineChartColors:Array<any> = [
    { // red
     // backgroundColor: 'rgba(244,67,54,0.2)',
      borderColor: 'rgba(244,67,54,1)',
      pointBackgroundColor: 'rgba(148,159,177,1)',
      pointBorderColor: '#fff',
      pointHoverBackgroundColor: '#fff',
      pointHoverBorderColor: 'rgba(148,159,177,0.8)'
    },
    { // yellow
      //backgroundColor: 'rgba(255,152,0,0.2)',
      borderColor: 'rgba(255,152,0,1)',
      pointBackgroundColor: 'rgba(77,83,96,1)',
      pointBorderColor: '#ebc944',
      pointHoverBackgroundColor: '#fff',
      pointHoverBorderColor: 'rgba(77,83,96,1)'
    },
    { // green
      //backgroundColor: 'rgba(76,175,80,0.2)',
      borderColor: 'rgba(76,175,80,1)',
      pointBackgroundColor: 'rgba(148,159,177,1)',
      pointBorderColor: '#fff',
      pointHoverBackgroundColor: '#fff',
      pointHoverBorderColor: 'rgba(148,159,177,0.8)'
    }
  ];
  public lineChartLegend:boolean = true;
  public lineChartType:string = 'line';

  public randomize(): void {
    let _lineChartData:Array<any> = new Array(this.lineChartData.length);
    for (let i = 0; i < this.lineChartData.length; i++) {
      _lineChartData[i] = {data: new Array(this.lineChartData[i].data.length), label: this.lineChartData[i].label};
      for (let j = 0; j < this.lineChartData[i].data.length; j++) {
        _lineChartData[i].data[j] = Math.floor((Math.random() * 100) + 1);
      }
    }
    this.lineChartData = _lineChartData;
  }

  // events
  public chartClicked(e:any):void {
    console.log(e);
  }

  public chartHovered(e:any):void {
    console.log(e);
  }

  // itemTypes=[{
  //   name:"Type I",
  //   value:1
  // },
  // {
  //   name:"Type II",
  //   value:2
  // },
  // {
  //   name:"Type III",
  //   value:3
  // }

  // ];
  // itemSize=[{
  //   name:"Small",
  //   value:1
  // },
  // {
  //   name:"Medium",
  //   value:2
  // },
  // {
  //   name:"Large",
  //   value:3
  // }

  // ];

  productType=["Type I", "Type II", "Type III"];
  lane=["lane 1","lane 2","lane 3"];
  returnData:any= undefined;
  constructor(private _apiService:ApiCallService) {
    this.lineChartData= [
      {data: [65, 59, 80, 81, 56, 55, 40], label: 'Cost'},
       {data: [28, 48, 40, 19, 86, 27, 90], label: 'Revenue'},
      {data: [18, 48, 77, 9, 100, 27, 40], label: 'Profit'}
    ];
  }

  ngDoCheck(){
    if(this.returnData!=undefined){
      this.lineChartData[0]=this.returnData;
    }
  }
  ngOnInit() {
  }

  submit(data){
    console.log("Form Data: ", data.value,this.lineChartData[0]);
    this.returnData= {data: [60, 55, 50, 45, 40, 35, 40] , label: "Rupees"};
    this.lineChartData[0]=this.returnData;
    console.log(this.lineChartData[0]);

  }

}
//https://github.com/valor-software/ng2-charts/issues/445