import { Injectable } from '@angular/core';
import {Http, HttpModule, Headers, RequestOptions} from '@angular/http';
import 'rxjs/add/operator/map';
import { Observable } from 'rxjs/Observable';

@Injectable()
export class ApiCallService {

  constructor(private http:Http) { }

  public getPredictionData(data:any):Observable<any>{
    const URL = 'www.url.com';

    const body = 'username=myusername&password=mypassword';


    const headers = new Headers();
    headers.append('Content-Type', 'application/x-www-form-urlencoded');
    const options = new RequestOptions({headers: headers});

    return this.http.post(URL, body, options).map(response => response.json());
  }

}
