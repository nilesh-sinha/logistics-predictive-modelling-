## Static File Server

This example sets up two static file servers. One at the default path (`/public`), and another at an explicit path (`/static`). You should be able to access the two files in the `./files` directory at either of those paths. So try `http://localhost:8000/static/b.txt` or `http://localhost:8000/public/a.html`.
